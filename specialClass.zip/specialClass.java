package mainClass;

public class specialClass {
	String name;
	public double Standard(double i) {
		return (i*10.764)*1200;
	}
	public double AboveStandard(double i) {
		return (i*10.764)*1500;
	}
	public double HighStandard(double i) {
		return (i*10.764)*1800;
	}
	public double HighStandardandAutomated(double i) {
		return (i*10.764)*2500;
	}

}
